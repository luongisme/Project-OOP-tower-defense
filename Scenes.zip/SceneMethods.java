package Scenes;

import java.awt.*;

public interface SceneMethods {
    public void render(Graphics g);
}
